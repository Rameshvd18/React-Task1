import React from 'react'
import GithubData from './FSC/GithubData'
import Navbar from './Navbar'
import Products from './FSC/Products'
import Footer from './Footer'

const App = () => {
  return (
    <div>
         <Navbar/>
        
      <GithubData/>
      {/* <Products/> */}
      <Footer/> 
    </div>
  )
}

export default App







// class based  components

// import { Component } from "react";

// class App extends Component {
//     render(){
//         return(
//             <div>
//                 <h1>Ramesh</h1>
//             </div>
//         )
//     }
// }
// export default App


//function based components

// function App(){
//     return(
//         <div>
//             <h1>Ramesh</h1>
//         </div>

//     )
// }
// export default App