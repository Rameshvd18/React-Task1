import React from 'react'
import ProductsData from "./ProductsData.json"
console.log(ProductsData);


const Products = () => {
  return (
    <div className='mainContainer'>
        {
      ProductsData.map((product)=>{
        console.log(Products)
        return(
            <article className='childContainer' >
               
                                
                <img src={product.images} alt="" />
                 <h1>{product.title}</h1>
                <h1> price:₹{product.price}/-</h1>
            </article>
        )

        
      })
    }
    </div>
  )
}

export default Products
