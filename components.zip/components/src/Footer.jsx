const Footer = () =>{

    return(

        <div className="footer-container">

            <p>@ copy rights Git Users 2025</p>

        </div>

    )

}
export default Footer;