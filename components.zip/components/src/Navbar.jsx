// import { Component } from "react";

// class Navbar extends Component{
//     render(){
//         return(
//             <div className="navbarContainer">
//             <h1>Home</h1>
//             <h1>About as</h1>
//             <h1>login</h1>
//             <h1>Register</h1>

//             </div>
//         )
//     }
// }
// export default Navbar;

const Navbar = () =>{

    return(
        <div className="navbar-container"> 
        <img src="https://github.githubassets.com/assets/GitHub-Mark-ea2971cee799.png" alt="" /> 
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#AboutUs">AboutUs</a></li>
                <li><a href="#Login">Login</a></li>
                <li><a href="#Register">Register</a></li>
            </ul>
        </div>
    )
}

export default Navbar;